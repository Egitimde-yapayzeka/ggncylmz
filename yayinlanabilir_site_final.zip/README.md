# Yapay Zeka Web Sitesi - Yayınlama Rehberi

Bu proje, eğitimde yapay zeka konulu bir statik web sitesidir. Aşağıdaki adımlarla **ücretsiz olarak yayınlayabilirsiniz**.

---

## 1. Netlify ile Yayınlama (Önerilen)
1. [https://app.netlify.com/drop](https://app.netlify.com/drop) adresine gidin.
2. `yayinlanabilir_site.zip` dosyasını sürükleyip bırakın.
3. Netlify dosyaları otomatik yükleyecek ve size `https://sitename.netlify.app` formatında bir bağlantı verecek.

---

## 2. GitHub Pages ile Yayınlama
1. [GitHub](https://github.com/) hesabınıza giriş yapın.
2. Yeni bir **repository** oluşturun (örn: `yapay-zeka-site`).
3. ZIP dosyasını açın ve içindeki dosyaları repository'ye yükleyin.
4. `Settings` → `Pages` sekmesine gidin ve **main branch**’i seçin.
5. 1 dakika içinde `https://kullaniciadi.github.io/yapay-zeka-site` adresinden yayında olacaktır.

---

## 3. Yerel Önizleme
- ZIP dosyasını bilgisayarınızda açın.
- **index.html** dosyasına çift tıklayarak tarayıcıda görüntüleyebilirsiniz.

---

**Not:** Bu site tamamen statik dosyalardan oluşmaktadır (HTML, CSS), bu yüzden ek sunucuya gerek yoktur.
